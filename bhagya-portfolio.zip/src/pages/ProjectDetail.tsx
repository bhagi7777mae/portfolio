import { useParams, Link } from "react-router-dom";
import { Layout } from "@/components/layout/Layout";
import { CodeDivider } from "@/components/ui/CodeDivider";
import { TechTag } from "@/components/ui/TechTag";
import { ArrowLeft, ExternalLink, Github } from "lucide-react";
import { Button } from "@/components/ui/button";

const projectsData: Record<string, {
  name: string;
  description: string;
  fullDescription: string;
  stack: string[];
  impact: string;
  challenges: string[];
  features: string[];
}> = {
  "og-company-web-developer": {
    name: "Web Developer Internship — OG Company",
    description: "Front-end development internship building a multi-themed website.",
    fullDescription:
      "On-site front-end internship at OG Company where I built a multi-themed website covering shopping, gaming, literature, and movies. I implemented the page structure, styling, and interactivity for each section along with a complete login and user registration flow.",
    stack: ["HTML", "CSS", "JavaScript", "UI/UX"],
    impact: "On-site internship, Jun–Jul 2025",
    challenges: [
      "Designing consistent UI across four very different content themes",
      "Building responsive layouts that work across screen sizes",
      "Implementing a clean login and registration flow",
      "Translating design ideas into accessible, semantic HTML/CSS",
    ],
    features: [
      "Shopping, gaming, literature, and movie website sections",
      "Login and user registration pages",
      "Responsive layouts and reusable components",
      "Hand-crafted UI with a focus on usability",
    ],
  },
  "code-alpha-cybersec-blockchain": {
    name: "Cyber Security & Blockchain — Code Alpha",
    description: "Network sniffing tool and a blockchain-based smart storage system.",
    fullDescription:
      "Virtual internship at Code Alpha focused on practical cyber security and blockchain. I built a network packet sniffing tool that captures and analyzes traffic on a network, and implemented a blockchain-powered smart storage prototype that records data immutably on a device.",
    stack: ["Python", "Blockchain", "Networking", "Security"],
    impact: "Virtual internship, Jul–Aug 2025",
    challenges: [
      "Capturing and decoding live network packets safely",
      "Understanding blockchain data structures and hashing",
      "Designing a tamper-evident local storage layer",
      "Working through a structured remote internship pipeline",
    ],
    features: [
      "Network packet sniffer with traffic analysis",
      "Blockchain-based smart storage prototype on a device",
      "Hash-linked records for tamper detection",
      "Documented learning outcomes and deliverables",
    ],
  },
  "slash-mark-app-cybersec": {
    name: "App Development & Cyber Security — Slash Mark",
    description: "Face-security app and an encrypted keylogger built during internship.",
    fullDescription:
      "Internship at Slash Mark focused on app development with a cyber-security angle. I delivered two projects: a face-recognition based security application that authenticates users via webcam, and a keylogger that captures keystrokes with built-in encryption so logs are stored safely.",
    stack: ["Python", "Face Recognition", "Cryptography", "App Dev"],
    impact: "Internship, May–Jun 2024",
    challenges: [
      "Integrating real-time face recognition into an authentication flow",
      "Storing sensitive captured data securely using encryption",
      "Balancing learning value with ethical / responsible use",
      "Shipping two distinct projects within a short internship window",
    ],
    features: [
      "Face-recognition based authentication app",
      "Keylogger with encrypted log storage",
      "Modular Python codebase",
      "Hands-on exposure to applied security concepts",
    ],
  },
  "nsic-app-development": {
    name: "App Development — NSIC Government Sector",
    description: "Basic smartphone apps: clock, games, and a photo-editing tool.",
    fullDescription:
      "Government-sector internship at NSIC focused on foundational mobile app development. I built a set of beginner smartphone applications including a clock app, casual games, and a basic photo-editing utility — covering UI design, core logic, and packaging.",
    stack: ["Android", "App Dev", "UI Design"],
    impact: "Government-sector internship, Dec 2024",
    challenges: [
      "Learning the full mobile app lifecycle from scratch",
      "Designing intuitive UIs for everyday utilities",
      "Implementing simple game logic and timers",
      "Working with image processing for the photo editor",
    ],
    features: [
      "Clock application with core time utilities",
      "Two simple, playable games",
      "Photo-editing tool with basic adjustments",
      "Clean, beginner-friendly UI design",
    ],
  },
};

export default function ProjectDetail() {
  const { slug } = useParams<{ slug: string }>();
  const project = slug ? projectsData[slug] : null;

  if (!project) {
    return (
      <Layout>
        <section className="py-20">
          <div className="container">
            <div className="text-center">
              <h1 className="text-3xl font-bold text-foreground mb-4">Project Not Found</h1>
              <p className="text-muted-foreground mb-8">The project you're looking for doesn't exist.</p>
              <Button asChild>
                <Link to="/work">
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Back to Work
                </Link>
              </Button>
            </div>
          </div>
        </section>
      </Layout>
    );
  }

  return (
    <Layout>
      <section className="py-20">
        <div className="container max-w-4xl">
          <Link
            to="/work"
            className="inline-flex items-center font-mono text-sm text-muted-foreground hover:text-primary transition-colors mb-8 opacity-0 animate-fade-in-up"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Work
          </Link>

          <div className="mb-12 opacity-0 animate-fade-in-up stagger-1">
            <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              {project.name}
            </h1>
            <p className="text-lg text-muted-foreground leading-relaxed mb-6">
              {project.fullDescription}
            </p>

            <div className="flex flex-wrap gap-2 mb-6">
              {project.stack.map((tech) => (
                <TechTag key={tech}>{tech}</TechTag>
              ))}
            </div>

            <div className="p-4 bg-primary/5 border border-primary/20 rounded-lg">
              <span className="font-mono text-sm text-primary">
                <span className="text-muted-foreground">{"//"}</span> {project.impact}
              </span>
            </div>
          </div>

          <div className="opacity-0 animate-fade-in-up stagger-2">
            <CodeDivider label="Challenges" />
          </div>

          <div className="mb-12 opacity-0 animate-fade-in-up stagger-3">
            <ul className="space-y-3">
              {project.challenges.map((challenge, index) => (
                <li key={index} className="flex items-start gap-3">
                  <span className="font-mono text-primary mt-1">→</span>
                  <span className="text-muted-foreground">{challenge}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="opacity-0 animate-fade-in-up stagger-3">
            <CodeDivider label="Highlights" />
          </div>

          <div className="mb-12 opacity-0 animate-fade-in-up stagger-4">
            <ul className="space-y-3">
              {project.features.map((feature, index) => (
                <li key={index} className="flex items-start gap-3">
                  <span className="font-mono text-primary mt-1">✓</span>
                  <span className="text-muted-foreground">{feature}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="flex flex-wrap gap-4 pt-8 border-t border-border opacity-0 animate-fade-in-up stagger-4">
            <Button variant="outline" className="font-mono" asChild>
              <a href="https://github.com/bhagi7777mae" target="_blank" rel="noopener noreferrer">
                <Github className="mr-2 h-4 w-4" />
                View GitHub
              </a>
            </Button>
            <Button variant="outline" className="font-mono" disabled>
              <ExternalLink className="mr-2 h-4 w-4" />
              Live Demo
            </Button>
          </div>
        </div>
      </section>
    </Layout>
  );
}
