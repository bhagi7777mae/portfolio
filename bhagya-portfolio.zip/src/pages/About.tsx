import { Layout } from "@/components/layout/Layout";
import { CodeDivider } from "@/components/ui/CodeDivider";
import { TechTag } from "@/components/ui/TechTag";
import profilePhoto from "@/assets/bhagya-profile.png";

const skills = [
  "Python",
  "Cloud Practitioner",
  "Problem Solving",
  "Front-End Development",
  "Scanning Tools",
  "HTML, CSS, JSON",
  "Web Design Tools",
];

const stack = [
  "Python",
  "C++",
  "Java",
  "HTML",
  "CSS",
  "JSON",
  "JavaScript",
  "Blockchain",
];

const education = [
  {
    title: "B.E. Computer Science (Cyber Security)",
    org: "J.N.N Institute of Engineering, Redhills",
    period: "2023 – Present",
    detail: "Current CGPA: 8.95 / 10",
  },
  {
    title: "Higher Secondary Certificate (HSC) — Class XII",
    org: "J.N.N Matric Hr. Secondary School, Kannigaipair",
    period: "2022 – 2023",
    detail: "Percentage: 65%",
  },
  {
    title: "Secondary School Leaving Certificate (SSLC) — Class X",
    org: "J.N.N Matric Hr. Secondary School, Kannigaipair",
    period: "Completed",
    detail: "Percentage: 64%",
  },
];

const certifications = [
  "AWS Cloud Practitioner Certificate",
  "Great Learning — Power of BI, Pillars of Cyber Security Threats",
  "Cisco Academy — Introduction to Cyber Security, Networking Basics, Ethical Hacking",
  "Cisco Academy — Essential Python, Java Programming",
  "HP Life — Data Science, AI for Beginners, Cyber Security Awareness",
  "Prepinsta — Java",
  "NPTEL — Ethical Hacking, Privacy and Security on Social Media",
  "IBM — Generative AI",
  "Simple Learning — Introduction to Cloud Security, Scale on Cloud Security",
];

export default function About() {
  return (
    <Layout>
      <section className="py-20">
        <div className="container">
          <div className="max-w-3xl mb-12 opacity-0 animate-fade-in-up">
            <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              About
            </h1>
          </div>

          <div className="grid gap-16 lg:grid-cols-3">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              <div className="flex flex-col sm:flex-row items-start gap-6 opacity-0 animate-fade-in-up stagger-1">
                <div className="relative w-32 h-32 md:w-36 md:h-36 shrink-0 rounded-lg overflow-hidden border-2 border-primary/30 transition-all duration-300 hover:border-primary">
                  <img
                    src={profilePhoto}
                    alt="Bhagya Sree M"
                    className="w-full h-full object-cover"
                  />
                </div>
                <p className="text-lg text-foreground leading-relaxed">
                  I'm <span className="text-primary font-medium">Bhagya Sree M</span>, a
                  passionate and motivated student currently pursuing a Bachelor of
                  Engineering in Computer Science with specialization in Cyber Security.
                </p>
              </div>

              <div className="opacity-0 animate-fade-in-up stagger-2">
                <p className="text-muted-foreground leading-relaxed">
                  I'm committed to continuous learning and personal growth, aiming to build
                  a strong foundation in cyber security while exploring web development,
                  blockchain, and mobile app development through internships and hands-on
                  projects.
                </p>
              </div>

              <div className="opacity-0 animate-fade-in-up stagger-3">
                <CodeDivider label="Education" />
              </div>

              <div className="space-y-4 opacity-0 animate-fade-in-up stagger-3">
                {education.map((item) => (
                  <div
                    key={item.title}
                    className="p-4 bg-card border border-border rounded-lg"
                  >
                    <div className="flex items-start justify-between gap-4 mb-1">
                      <h3 className="font-mono text-sm text-foreground">{item.title}</h3>
                      <span className="font-mono text-xs text-primary whitespace-nowrap">
                        {item.period}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground">{item.org}</p>
                    <p className="font-mono text-xs text-primary mt-2">
                      <span className="text-muted-foreground">{"//"}</span> {item.detail}
                    </p>
                  </div>
                ))}
              </div>

              <div className="opacity-0 animate-fade-in-up stagger-4">
                <CodeDivider label="Certifications" />
              </div>

              <div className="space-y-2 font-mono text-sm opacity-0 animate-fade-in-up stagger-4">
                {certifications.map((cert) => (
                  <p
                    key={cert}
                    className="text-muted-foreground transition-colors hover:text-foreground"
                  >
                    <span className="text-primary mr-2">→</span>
                    {cert}
                  </p>
                ))}
              </div>
            </div>

            {/* Sidebar */}
            <div className="space-y-8">
              <div className="opacity-0 animate-fade-in-up stagger-2">
                <h2 className="font-mono text-sm text-primary mb-4">
                  <span className="text-muted-foreground">/*</span> Skills{" "}
                  <span className="text-muted-foreground">*/</span>
                </h2>
                <ul className="space-y-2">
                  {skills.map((skill) => (
                    <li
                      key={skill}
                      className="text-sm text-muted-foreground transition-colors hover:text-foreground"
                    >
                      <span className="text-primary mr-2">→</span>
                      {skill}
                    </li>
                  ))}
                </ul>
              </div>

              <div className="opacity-0 animate-fade-in-up stagger-3">
                <h2 className="font-mono text-sm text-primary mb-4">
                  <span className="text-muted-foreground">/*</span> Stack{" "}
                  <span className="text-muted-foreground">*/</span>
                </h2>
                <div className="flex flex-wrap gap-2">
                  {stack.map((tech) => (
                    <TechTag key={tech}>{tech}</TechTag>
                  ))}
                </div>
              </div>

              <div className="opacity-0 animate-fade-in-up stagger-4">
                <h2 className="font-mono text-sm text-primary mb-4">
                  <span className="text-muted-foreground">/*</span> Focus{" "}
                  <span className="text-muted-foreground">*/</span>
                </h2>
                <div className="space-y-3 text-sm text-muted-foreground">
                  <p>Cyber Security &amp; Ethical Hacking</p>
                  <p>Front-end Development</p>
                  <p>App Development &amp; Blockchain</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}
