import { Link } from "react-router-dom";
import { Layout } from "@/components/layout/Layout";
import { Button } from "@/components/ui/button";
import { CodeDivider } from "@/components/ui/CodeDivider";
import { CodeLabel } from "@/components/ui/CodeLabel";
import { ProjectCard } from "@/components/ui/ProjectCard";
import { TypingCursor } from "@/components/ui/TypingCursor";
import { ArrowRight } from "lucide-react";
import profilePhoto from "@/assets/bhagya-profile.png";

const featuredProjects = [
  {
    name: "Cyber Security & Blockchain — Code Alpha",
    slug: "code-alpha-cybersec-blockchain",
    description: "Created a network packet sniffing tool and implemented a blockchain-based smart storage system on a device.",
    stack: ["Python", "Blockchain", "Networking"],
    impact: "Hands-on virtual internship in cyber security and blockchain (Jul–Aug 2025)",
  },
  {
    name: "App Development & Cyber Security — Slash Mark",
    slug: "slash-mark-app-cybersec",
    description: "Built a face-recognition based security application and a keylogger with encryption for safe data capture.",
    stack: ["Python", "Security", "App Dev"],
    impact: "Two security-focused apps delivered during internship (May–Jun 2024)",
  },
  {
    name: "App Development — NSIC Government Sector",
    slug: "nsic-app-development",
    description: "Developed basic smartphone applications including a clock, mini games, and a photo-editing utility.",
    stack: ["Android", "App Dev", "UI Design"],
    impact: "Government-sector internship building consumer mobile apps (Dec 2024)",
  },
];

export default function Home() {
  return (
    <Layout>
      {/* Hero Section */}
      <section className="relative min-h-[80vh] flex items-center bg-grid">
        <div className="container">
          <div className="grid gap-10 lg:grid-cols-[1fr_auto] lg:items-center">
          <div className="max-w-3xl opacity-0 animate-fade-in-up">
            <CodeLabel className="mb-6">Cyber Security Student</CodeLabel>

            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mb-6 leading-tight">
              Hi, I'm Bhagya Sree M.
              <br />
              <span className="text-muted-foreground">I build secure, reliable software</span>
              <TypingCursor />
            </h1>

            <p className="text-lg text-muted-foreground mb-8 max-w-xl leading-relaxed opacity-0 animate-fade-in-up stagger-1">
              A passionate B.E. Computer Science student specializing in Cyber Security at
              J.N.N Institute of Engineering. I love turning ideas into working products —
              from front-end websites to security tools and mobile apps.
            </p>

            <div className="opacity-0 animate-fade-in-up stagger-2">
              <Button asChild size="lg" className="font-mono transition-transform hover:scale-105">
                <Link to="/work">
                  View Work
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>

            <div className="opacity-0 animate-fade-in-up stagger-2 flex justify-center lg:justify-end">
              <div className="relative w-56 h-56 md:w-64 md:h-64 rounded-full overflow-hidden border-4 border-primary/40 glow-primary transition-all duration-300 hover:border-primary">
                <img
                  src={profilePhoto}
                  alt="Bhagya Sree M"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Projects */}
      <section className="py-20">
        <div className="container">
          <div className="opacity-0 animate-fade-in-up">
            <CodeDivider label="Featured Work" />
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            {featuredProjects.map((project, index) => (
              <div 
                key={project.name} 
                className={`opacity-0 animate-fade-in-up stagger-${index + 1}`}
              >
                <ProjectCard {...project} className="hover-lift" />
              </div>
            ))}
          </div>

          <div className="mt-12 text-center opacity-0 animate-fade-in-up stagger-4">
            <Link 
              to="/work" 
              className="inline-flex items-center font-mono text-sm text-muted-foreground hover:text-primary transition-colors link-underline"
            >
              <span className="text-primary mr-2">{"//"}</span>
              View all projects
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>
    </Layout>
  );
}
