import { Layout } from "@/components/layout/Layout";
import { CodeDivider } from "@/components/ui/CodeDivider";
import { ProjectCard } from "@/components/ui/ProjectCard";

const projects = [
  {
    name: "Cyber Security & Blockchain — Code Alpha",
    slug: "code-alpha-cybersec-blockchain",
    description: "Virtual internship focused on practical cyber security. Built a network sniffing tool to capture and analyze packets, and implemented a blockchain-powered smart storage system on a device.",
    stack: ["Python", "Blockchain", "Networking", "Security"],
    impact: "Virtual internship, Jul–Aug 2025",
  },
  {
    name: "App Development & Cyber Security — Slash Mark",
    slug: "slash-mark-app-cybersec",
    description: "Designed and developed two security-focused applications: a face-recognition based authentication app and a keylogger with built-in encryption for safe data handling.",
    stack: ["Python", "Face Recognition", "Cryptography"],
    impact: "Internship, May–Jun 2024",
  },
  {
    name: "App Development — NSIC Government Sector",
    slug: "nsic-app-development",
    description: "Built foundational smartphone applications during a government-sector internship, including a clock, casual games, and a photo-editing tool — covering the full app lifecycle from UI to packaging.",
    stack: ["Android", "App Dev", "UI Design"],
    impact: "Government-sector internship, Dec 2024",
  },
];

export default function Work() {
  return (
    <Layout>
      <section className="py-20">
        <div className="container">
          <div className="max-w-2xl mb-12 opacity-0 animate-fade-in-up">
            <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Work
            </h1>
            <p className="text-muted-foreground leading-relaxed">
              A selection of internships and projects from my journey as a Computer Science
              student specializing in cyber security — spanning web development, security
              tools, blockchain, and mobile applications.
            </p>
          </div>

          <div className="opacity-0 animate-fade-in-up stagger-1">
            <CodeDivider label="Projects" />
          </div>

          <div className="grid gap-8">
            {projects.map((project, index) => (
              <div 
                key={project.name}
                className={`opacity-0 animate-fade-in-up stagger-${Math.min(index + 2, 4)}`}
              >
                <ProjectCard {...project} className="hover-lift" />
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
}
